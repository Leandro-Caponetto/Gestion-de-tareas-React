
import React, { useState, useEffect } from 'react';
import { supabase } from './lib/supabaseClient';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TaskForm from './components/TaskForm';
import RecentActivity from './components/RecentActivity';
import Reports from './components/Reports';
import TaskDetailModal from './components/TaskDetailModal';
import Auth from './components/Auth';
import { Task, ViewType } from './types';
import { handleExport } from './services/exportService';

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('taskpulse_darkmode') === 'true';
  });

  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  // Escuchar cambios de sesión
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Cargar tareas de Supabase al iniciar sesión
  useEffect(() => {
    if (session) {
      fetchTasks();
    }
  }, [session]);

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('fecha', { ascending: false });

      if (error) throw error;
      setTasks(data || []);
    } catch (error: any) {
      console.error('Error fetching tasks:', error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    localStorage.setItem('taskpulse_darkmode', isDarkMode.toString());
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const addTask = async (taskData: Omit<Task, 'id'>) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .insert([{ ...taskData, user_id: session.user.id }])
        .select();

      if (error) throw error;
      if (data) {
        setTasks(prev => [data[0], ...prev]);
        setCurrentView('dashboard');
      }
    } catch (error: any) {
      alert('Error al guardar: ' + error.message);
    }
  };

  const updateTask = async (updatedTask: Task) => {
    try {
      const { error } = await supabase
        .from('tasks')
        .update(updatedTask)
        .eq('id', updatedTask.id);

      if (error) throw error;
      setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
      setEditingTask(null);
    } catch (error: any) {
      alert('Error al actualizar: ' + error.message);
    }
  };

  const deleteTask = async (id: string) => {
    if (confirm('¿Desea dar de baja este registro oficial de la nube?')) {
      try {
        const { error } = await supabase.from('tasks').delete().eq('id', id);
        if (error) throw error;
        setTasks(prev => prev.filter(t => t.id !== id));
        if (editingTask?.id === id) setEditingTask(null);
      } catch (error: any) {
        alert('Error al eliminar: ' + error.message);
      }
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  if (!session) {
    return <Auth />;
  }

  const renderView = () => {
    if (loading) return (
      <div className="flex flex-col items-center justify-center h-full py-40">
        <div className="w-12 h-12 border-4 border-correo-yellow border-t-correo-blue rounded-full animate-spin"></div>
        <p className="mt-6 text-xs font-black text-correo-blue uppercase tracking-widest animate-pulse">Sincronizando con Servidor Central...</p>
      </div>
    );

    switch (currentView) {
      case 'dashboard':
        return (
          <div className="space-y-12 pb-20">
            <Dashboard tasks={tasks} />
            <RecentActivity 
              tasks={tasks.slice(0, 10)} 
              onDelete={deleteTask} 
              onEdit={(task) => setEditingTask(task)}
              onExport={(filtered) => handleExport(filtered)}
            />
          </div>
        );
      case 'registro':
        return (
          <div className="space-y-12 pb-20">
            <TaskForm onAddTask={addTask} />
            <RecentActivity 
              tasks={tasks} 
              onDelete={deleteTask} 
              onEdit={(task) => setEditingTask(task)}
              onExport={(filtered) => handleExport(filtered)}
            />
          </div>
        );
      case 'reportes':
        return <Reports tasks={tasks} />;
      case 'configuracion':
        return (
          <div className="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] border-2 border-slate-100 dark:border-slate-800 shadow-2xl transition-all">
            <h2 className="text-3xl font-black text-correo-blue dark:text-correo-yellow mb-4 uppercase tracking-tighter italic">Ajustes de Terminal</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-10 font-bold uppercase tracking-widest text-xs">Sesión Activa: {session.user.email}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="flex items-center justify-between p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border-2 border-transparent transition-all">
                <div>
                  <p className="font-black text-correo-blue dark:text-white uppercase tracking-wide">Visibilidad Nocturna</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest mt-1">Esquema de alto contraste</p>
                </div>
                <button 
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  className={`w-16 h-8 rounded-full relative transition-all duration-300 shadow-inner ${isDarkMode ? 'bg-correo-yellow' : 'bg-slate-300'}`}
                >
                  <div className={`absolute top-1 w-6 h-6 bg-white rounded-full shadow-md transition-all duration-300 ${isDarkMode ? 'right-1' : 'left-1'}`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-8 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border-2 border-transparent transition-all">
                <div>
                  <p className="font-black text-correo-blue dark:text-white uppercase tracking-wide">Cerrar Sesión</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-widest mt-1">Salir de esta terminal</p>
                </div>
                <button 
                  onClick={handleLogout}
                  className="bg-red-500 text-white px-6 py-2.5 rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg shadow-red-500/20"
                >
                  Desconectar
                </button>
              </div>
            </div>
          </div>
        );
      default:
        return <Dashboard tasks={tasks} />;
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      <Sidebar currentView={currentView} onViewChange={setCurrentView} />
      
      <main className="flex-1 ml-64 p-12 min-w-0">
        <div className="max-w-7xl mx-auto">
          {renderView()}
        </div>
      </main>

      {/* Primary Brand Floating Button */}
      {currentView !== 'registro' && (
        <button 
          onClick={() => setCurrentView('registro')}
          className="fixed bottom-12 right-12 bg-correo-blue text-correo-yellow p-6 rounded-[2.5rem] shadow-2xl shadow-correo-blue/40 hover:scale-110 active:scale-95 transition-all z-40 group border-8 border-correo-yellow/20"
          aria-label="Cargar nueva tarea"
        >
          <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      )}

      {/* Task Detail / Edit Modal */}
      {editingTask && (
        <TaskDetailModal 
          task={editingTask} 
          onClose={() => setEditingTask(null)} 
          onSave={updateTask}
          onDelete={deleteTask}
        />
      )}
    </div>
  );
};

export default App;
