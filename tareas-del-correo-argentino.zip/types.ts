
export enum TaskCategory {
  Desarrollo = 'Desarrollo',
  QA = 'QA',
  Meeting = 'Meeting',
  Research = 'Research',
  Admin = 'Admin'
}

export type TaskStatus = 'Facturable' | 'No facturable';

export interface Task {
  id: string;
  fecha: string;
  cliente: string;
  proyecto: string;
  descripcion: string;
  categoria: TaskCategory;
  hora_inicio: string;
  hora_fin: string;
  total_horas: number;
  etiquetas: string[];
  estado: TaskStatus;
}

export type ViewType = 'dashboard' | 'registro' | 'reportes' | 'configuracion';
