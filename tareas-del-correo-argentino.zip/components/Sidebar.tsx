
import React from 'react';
import { LayoutDashboard, ClipboardList, BarChart3, Settings, LogOut } from 'lucide-react';
import { ViewType } from '../types';
import { supabase } from '../lib/supabaseClient';

interface SidebarProps {
  currentView: ViewType;
  onViewChange: (view: ViewType) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Panel Operativo', icon: LayoutDashboard },
    { id: 'registro', label: 'Carga de Tareas', icon: ClipboardList },
    { id: 'reportes', label: 'Reportes', icon: BarChart3 },
    { id: 'configuracion', label: 'Configuración', icon: Settings },
  ];

  return (
    <aside className="w-64 h-screen bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col fixed left-0 top-0 transition-colors duration-300 z-50">
      <div className="p-8">
        <div className="flex flex-col items-center gap-4 text-center">
          <div className="bg-correo-yellow p-4 rounded-3xl flex items-center justify-center shadow-lg shadow-correo-yellow/20">
            <svg viewBox="0 0 100 100" className="w-16 h-16 text-correo-blue" fill="currentColor">
              <rect x="10" y="32" width="40" height="12" rx="2" />
              <path d="M20,48 C20,85 85,85 85,48 L70,48 C70,70 35,70 35,48 Z" />
              <circle cx="65" cy="45" r="22" stroke="currentColor" strokeWidth="6" fill="none" />
              <circle cx="65" cy="45" r="10" fill="currentColor" />
            </svg>
          </div>
          <div className="space-y-0">
            <h1 className="text-xl font-black text-correo-blue dark:text-correo-yellow tracking-tighter uppercase leading-none">
              TAREAS DEL
            </h1>
            <p className="text-sm font-extrabold text-correo-blue dark:text-correo-yellow tracking-[0.2em] uppercase">
              CORREO
            </p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id as ViewType)}
            className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all duration-300 group ${
              currentView === item.id 
                ? 'bg-correo-blue text-correo-yellow shadow-xl shadow-correo-blue/20 font-bold translate-x-1' 
                : 'text-slate-500 dark:text-slate-400 hover:bg-correo-yellow/10 dark:hover:bg-correo-yellow/5 hover:text-correo-blue dark:hover:text-correo-yellow'
            }`}
          >
            <item.icon className={`w-5 h-5 transition-transform group-hover:scale-110 ${currentView === item.id ? 'text-correo-yellow' : 'text-slate-400 dark:text-slate-500'}`} />
            <span className="text-sm uppercase tracking-wide font-black">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 space-y-4">
        <button 
          onClick={() => supabase.auth.signOut()}
          className="w-full flex items-center justify-center gap-3 py-3 rounded-2xl border-2 border-slate-100 dark:border-slate-800 text-slate-400 hover:text-red-500 hover:border-red-100 dark:hover:border-red-900 transition-all font-black text-[10px] uppercase tracking-widest"
        >
          <LogOut className="w-4 h-4" />
          Desconectar
        </button>
        
        <div className="bg-correo-yellow rounded-3xl p-5 shadow-inner">
          <p className="text-[10px] text-correo-blue/70 font-black mb-1 uppercase tracking-widest">Estado Nube</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <p className="text-xs font-black text-correo-blue uppercase">Cloud Sync</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
