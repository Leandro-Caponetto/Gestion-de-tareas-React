
import React, { useState } from 'react';
import { Task, TaskCategory } from '../types';
import { CATEGORIES } from '../constants';
import { Filter, Search, Download, Trash2, Eye, Calendar, Clock } from 'lucide-react';

interface RecentActivityProps {
  tasks: Task[];
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
  onExport: (filteredTasks: Task[]) => void;
}

type TimeFilter = 'all' | 'today' | 'month';

const RecentActivity: React.FC<RecentActivityProps> = ({ tasks, onDelete, onEdit, onExport }) => {
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = new Date().toISOString().slice(0, 7); // YYYY-MM

  const filteredTasks = tasks.filter(t => {
    const matchesCategory = filterCategory === 'All' || t.categoria === filterCategory;
    const matchesSearch = t.descripcion.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.cliente.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.proyecto.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesTime = true;
    if (timeFilter === 'today') {
      matchesTime = t.fecha === todayStr;
    } else if (timeFilter === 'month') {
      matchesTime = t.fecha.startsWith(currentMonthStr);
    }

    return matchesCategory && matchesSearch && matchesTime;
  });

  const getCategoryColor = (cat: TaskCategory) => {
    switch (cat) {
      case TaskCategory.Desarrollo: return 'bg-correo-blue text-white';
      case TaskCategory.QA: return 'bg-amber-500 text-white';
      case TaskCategory.Meeting: return 'bg-correo-yellow text-correo-blue';
      case TaskCategory.Research: return 'bg-slate-800 text-white';
      case TaskCategory.Admin: return 'bg-slate-200 text-slate-700';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 shadow-2xl transition-all overflow-hidden">
      <div className="p-8 border-b border-slate-100 dark:border-slate-800 flex flex-col xl:flex-row xl:items-center justify-between gap-6">
        <div>
          <h3 className="text-2xl font-black text-correo-blue dark:text-white uppercase tracking-tight">Actividad Operativa</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1 italic">
            {timeFilter === 'today' ? 'Mostrando registros de HOY' : timeFilter === 'month' ? 'Mostrando registros del MES' : 'Bitácora general de tareas'}
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {/* Time Filters */}
          <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border-2 border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setTimeFilter('all')}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${timeFilter === 'all' ? 'bg-white dark:bg-slate-700 text-correo-blue dark:text-correo-yellow shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Todo
            </button>
            <button
              onClick={() => setTimeFilter('today')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${timeFilter === 'today' ? 'bg-correo-blue text-correo-yellow shadow-md scale-105' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <Clock className="w-3 h-3" />
              Hoy
            </button>
            <button
              onClick={() => setTimeFilter('month')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${timeFilter === 'month' ? 'bg-correo-blue text-correo-yellow shadow-md scale-105' : 'text-slate-400 hover:text-slate-600'}`}
            >
              <Calendar className="w-3 h-3" />
              Mes
            </button>
          </div>

          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-12 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-correo-yellow rounded-2xl text-sm focus:ring-0 dark:text-white transition-all w-full font-bold outline-none"
            />
          </div>

          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-2xl border-2 border-transparent">
            <Filter className="w-4 h-4 text-slate-400" />
            <select
              value={filterCategory}
              onChange={e => setFilterCategory(e.target.value)}
              className="bg-transparent text-xs font-black text-correo-blue dark:text-slate-300 focus:outline-none uppercase tracking-widest cursor-pointer"
            >
              <option value="All">Categoría</option>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <button 
            onClick={() => onExport(filteredTasks)}
            className="flex items-center gap-2 bg-correo-yellow text-correo-blue px-6 py-3 rounded-2xl text-xs font-black hover:bg-correo-yellow/80 transition-all shadow-lg shadow-correo-yellow/20 uppercase tracking-widest border-2 border-correo-blue/5"
          >
            <Download className="w-4 h-4" />
            {timeFilter === 'today' ? 'Exportar Hoy' : timeFilter === 'month' ? 'Exportar Mes' : 'Exportar Todo'}
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50 dark:bg-slate-800/50">
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Destino / Proyecto</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Tipo</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Dedicación</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Situación</th>
              <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Acción</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
            {filteredTasks.length > 0 ? filteredTasks.map((task) => (
              <tr 
                key={task.id} 
                className="hover:bg-correo-yellow/5 dark:hover:bg-correo-yellow/5 transition-all group cursor-pointer"
                onClick={() => onEdit(task)}
              >
                <td className="px-8 py-6">
                  <div className="flex flex-col">
                    <span className="text-sm font-black text-correo-blue dark:text-white uppercase leading-none">{task.proyecto}</span>
                    <span className="text-[10px] text-slate-400 font-bold flex items-center gap-1 mt-1.5 uppercase tracking-widest">
                      {task.cliente} • {task.fecha}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <span className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest inline-block ${getCategoryColor(task.categoria)}`}>
                    {task.categoria}
                  </span>
                </td>
                <td className="px-8 py-6">
                  <div className="flex flex-col">
                    <span className="text-sm font-black text-correo-blue dark:text-white">{task.total_horas}h</span>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{task.hora_inicio} » {task.hora_fin}</span>
                  </div>
                </td>
                <td className="px-8 py-6">
                  <span className={`text-[10px] font-black uppercase tracking-widest ${task.estado === 'Facturable' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400 dark:text-slate-500'}`}>
                    {task.estado}
                  </span>
                </td>
                <td className="px-8 py-6 text-right" onClick={(e) => e.stopPropagation()}>
                  <div className="flex justify-end gap-3 md:opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                      onClick={() => onEdit(task)}
                      className="p-3 bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 text-correo-blue dark:text-correo-yellow rounded-xl hover:bg-correo-yellow hover:text-correo-blue transition-all"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => onDelete(task.id)}
                      className="p-3 bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 text-red-300 hover:text-white hover:bg-red-500 transition-all"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-8 py-24 text-center text-slate-300 dark:text-slate-600 italic font-bold uppercase tracking-widest text-sm">
                  {timeFilter === 'all' ? 'Sin registros operacionales pendientes' : `Sin registros para este ${timeFilter === 'today' ? 'día' : 'mes'}`}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RecentActivity;
