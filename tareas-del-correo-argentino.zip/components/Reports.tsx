
import React from 'react';
import { Task } from '../types';
import { BarChart3, TrendingUp } from 'lucide-react';

interface ReportsProps {
  tasks: Task[];
}

const Reports: React.FC<ReportsProps> = ({ tasks }) => {
  const monthlyData = tasks.reduce((acc, task) => {
    const month = new Date(task.fecha).toLocaleString('es-ES', { month: 'long', year: 'numeric' });
    acc[month] = (acc[month] || 0) + task.total_horas;
    return acc;
  }, {} as Record<string, number>);

  const yearlyData = tasks.reduce((acc, task) => {
    const year = new Date(task.fecha).getFullYear().toString();
    acc[year] = (acc[year] || 0) + task.total_horas;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-8 animate-in zoom-in-95 duration-500">
      <header>
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">Reportes de Rendimiento</h2>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Análisis histórico detallado.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-indigo-50 dark:bg-indigo-900/20 p-2 rounded-xl text-indigo-600 dark:text-indigo-400">
              <BarChart3 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Resumen Mensual</h3>
          </div>
          <div className="space-y-4">
            {(Object.entries(monthlyData) as [string, number][]).map(([month, hours]) => (
              <div key={month} className="flex items-center justify-between group">
                <span className="text-slate-600 dark:text-slate-300 font-medium capitalize">{month}</span>
                <div className="flex items-center gap-4 flex-1 mx-4">
                  <div className="flex-1 bg-slate-50 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full rounded-full transition-all duration-1000" 
                      style={{ width: `${Math.min((hours / 160) * 100, 100)}%` }} 
                    />
                  </div>
                  <span className="text-slate-900 dark:text-white font-bold min-w-[60px] text-right">{hours.toFixed(1)}h</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-2 rounded-xl text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Resumen Anual</h3>
          </div>
          <div className="space-y-4">
            {(Object.entries(yearlyData) as [string, number][]).map(([year, hours]) => (
              <div key={year} className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{year}</p>
                  <p className="text-2xl font-black text-slate-900 dark:text-white">{hours.toFixed(1)}h</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-500">Promedio mensual</p>
                  <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{(hours / 12).toFixed(1)}h</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
