
import React, { useState } from 'react';
import { CLIENTS, PROJECTS, CATEGORIES } from '../constants';
import { Task, TaskCategory, TaskStatus } from '../types';
import { PlusCircle, CheckCircle2 } from 'lucide-react';
import { calculateDuration } from '../utils/timeUtils';

interface TaskFormProps {
  onAddTask: (task: Omit<Task, 'id'>) => void;
}

const TaskForm: React.FC<TaskFormProps> = ({ onAddTask }) => {
  const [formData, setFormData] = useState({
    fecha: new Date().toISOString().split('T')[0],
    cliente: '',
    proyecto: '',
    descripcion: '',
    categoria: TaskCategory.Desarrollo,
    hora_inicio: '08:00',
    hora_fin: '09:00',
    etiquetas: '',
    estado: 'Facturable' as TaskStatus
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.cliente) newErrors.cliente = 'Seleccionar Destino';
    if (!formData.proyecto) newErrors.proyecto = 'Seleccionar Proyecto';
    if (!formData.descripcion) newErrors.descripcion = 'Requerido';
    
    const duration = calculateDuration(formData.hora_inicio, formData.hora_fin);
    if (duration <= 0) newErrors.hora = 'Invalido';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const tags = formData.etiquetas.split(',').map(tag => tag.trim()).filter(t => t !== '');
      onAddTask({
        ...formData,
        total_horas: calculateDuration(formData.hora_inicio, formData.hora_fin),
        etiquetas: tags
      });
      setFormData(prev => ({ ...prev, descripcion: '', etiquetas: '' }));
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] border-2 border-slate-100 dark:border-slate-800 shadow-2xl max-w-5xl mx-auto transition-colors">
      <div className="flex items-center gap-4 mb-10">
        <div className="bg-correo-blue p-3.5 rounded-3xl shadow-xl shadow-correo-blue/20">
          <PlusCircle className="w-8 h-8 text-correo-yellow" />
        </div>
        <div>
          <h2 className="text-3xl font-black text-correo-blue dark:text-white uppercase tracking-tighter">Nueva Hoja de Ruta</h2>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Carga de registro operacional diario</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 font-bold">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Fecha Operación</label>
            <input
              type="date"
              value={formData.fecha}
              onChange={e => setFormData({ ...formData, fecha: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-correo-yellow rounded-2xl px-5 py-4 dark:text-white outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Destino / Cliente</label>
            <select
              value={formData.cliente}
              onChange={e => setFormData({ ...formData, cliente: e.target.value, proyecto: '' })}
              className={`w-full bg-slate-50 dark:bg-slate-800 border-2 ${errors.cliente ? 'border-red-400' : 'border-transparent focus:border-correo-yellow'} rounded-2xl px-5 py-4 dark:text-white outline-none transition-all cursor-pointer`}
            >
              <option value="">Seleccionar...</option>
              {CLIENTS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Proyecto Asignado</label>
            <select
              value={formData.proyecto}
              disabled={!formData.cliente}
              onChange={e => setFormData({ ...formData, proyecto: e.target.value })}
              className={`w-full bg-slate-50 dark:bg-slate-800 border-2 ${errors.proyecto ? 'border-red-400' : 'border-transparent focus:border-correo-yellow'} rounded-2xl px-5 py-4 dark:text-white outline-none transition-all cursor-pointer disabled:opacity-50`}
            >
              <option value="">Seleccionar...</option>
              {formData.cliente && PROJECTS[formData.cliente].map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Categoría Servicio</label>
            <select
              value={formData.categoria}
              onChange={e => setFormData({ ...formData, categoria: e.target.value as TaskCategory })}
              className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-correo-yellow rounded-2xl px-5 py-4 dark:text-white outline-none transition-all cursor-pointer"
            >
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Entrada</label>
            <input
              type="time"
              value={formData.hora_inicio}
              onChange={e => setFormData({ ...formData, hora_inicio: e.target.value })}
              className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-correo-yellow rounded-2xl px-5 py-4 dark:text-white outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Salida</label>
            <input
              type="time"
              value={formData.hora_fin}
              onChange={e => setFormData({ ...formData, hora_fin: e.target.value })}
              className={`w-full bg-slate-50 dark:bg-slate-800 border-2 ${errors.hora ? 'border-red-400' : 'border-transparent focus:border-correo-yellow'} rounded-2xl px-5 py-4 dark:text-white outline-none transition-all`}
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] ml-1">Resumen del Turno</label>
          <textarea
            rows={4}
            value={formData.descripcion}
            onChange={e => setFormData({ ...formData, descripcion: e.target.value })}
            placeholder="Detalle los hitos alcanzados en este bloque de tiempo..."
            className={`w-full bg-slate-50 dark:bg-slate-800 border-2 ${errors.descripcion ? 'border-red-400' : 'border-transparent focus:border-correo-yellow'} rounded-[2rem] px-6 py-5 dark:text-white resize-none outline-none transition-all text-base`}
          />
        </div>

        <div className="flex justify-center pt-8">
          <button
            type="submit"
            className="flex items-center justify-center gap-3 bg-correo-blue text-correo-yellow font-black px-16 py-5 rounded-[2.5rem] hover:bg-correo-blue-light transition-all shadow-2xl shadow-correo-blue/20 uppercase tracking-[0.15em] text-sm group"
          >
            <CheckCircle2 className="w-6 h-6 group-hover:scale-110 transition-transform" />
            Emitir Registro Oficial
          </button>
        </div>
      </form>
    </div>
  );
};

export default TaskForm;
