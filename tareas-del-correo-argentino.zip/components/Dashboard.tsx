
import React, { useMemo } from 'react';
import { Task, TaskCategory } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend 
} from 'recharts';
import { Clock, TrendingUp, Briefcase, Calendar } from 'lucide-react';

interface DashboardProps {
  tasks: Task[];
}

// Brand-specific colors for charts
const BRAND_CHART_COLORS = ['#00205b', '#ffce00', '#0047cc', '#eab308', '#1e293b'];

const Dashboard: React.FC<DashboardProps> = ({ tasks }) => {
  const today = new Date().toISOString().split('T')[0];
  
  const stats = useMemo(() => {
    const todayHours = tasks
      .filter(t => t.fecha === today)
      .reduce((acc, curr) => acc + curr.total_horas, 0);

    const weekHours = tasks.reduce((acc, curr) => acc + curr.total_horas, 0); 
    
    const projectsCount: Record<string, number> = {};
    tasks.forEach(t => {
      projectsCount[t.proyecto] = (projectsCount[t.proyecto] || 0) + t.total_horas;
    });
    
    const leadProject = Object.entries(projectsCount).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    return { todayHours, weekHours, leadProject };
  }, [tasks, today]);

  const barData = useMemo(() => {
    const dates = [...Array(7)].map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - i);
      return d.toISOString().split('T')[0];
    }).reverse();

    return dates.map(date => ({
      name: new Date(date).toLocaleDateString('es-ES', { weekday: 'short' }),
      horas: tasks.filter(t => t.fecha === date).reduce((acc, curr) => acc + curr.total_horas, 0)
    }));
  }, [tasks]);

  const pieData = useMemo(() => {
    const data: Record<string, number> = {};
    tasks.forEach(t => {
      data[t.categoria] = (data[t.categoria] || 0) + t.total_horas;
    });
    return Object.entries(data).map(([name, value]) => ({ name, value }));
  }, [tasks]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-4xl font-black text-correo-blue dark:text-correo-yellow tracking-tighter uppercase italic">Panel de Control</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1 text-lg font-medium italic">Correo Argentino - Monitoreo de Productividad</p>
        </div>
        <div className="hidden md:flex items-center gap-3 text-correo-blue dark:text-correo-yellow bg-correo-yellow dark:bg-slate-900 px-6 py-2.5 rounded-2xl border border-correo-blue/10 shadow-lg shadow-correo-yellow/20 transition-all font-black uppercase text-xs">
          <Calendar className="w-4 h-4" />
          <span>{new Date().toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
        </div>
      </header>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none transition-all hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest mb-1">Jornada de Hoy</p>
              <h3 className="text-5xl font-black text-correo-blue dark:text-white">{stats.todayHours}h</h3>
            </div>
            <div className="p-4 bg-correo-yellow rounded-3xl shadow-lg shadow-correo-yellow/30">
              <Clock className="w-7 h-7 text-correo-blue" />
            </div>
          </div>
        </div>

        <div className="bg-correo-blue p-8 rounded-[2rem] shadow-2xl shadow-correo-blue/30 transition-all hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-white/50 text-xs font-black uppercase tracking-widest mb-1 text-correo-yellow">Total Semanal</p>
              <h3 className="text-5xl font-black text-white">{stats.weekHours}h</h3>
            </div>
            <div className="p-4 bg-correo-yellow rounded-3xl shadow-lg">
              <TrendingUp className="w-7 h-7 text-correo-blue" />
            </div>
          </div>
          <div className="w-full bg-white/10 rounded-full h-2.5 mt-6 overflow-hidden">
            <div className="bg-correo-yellow h-full rounded-full transition-all duration-1000" style={{ width: `${Math.min((stats.weekHours / 40) * 100, 100)}%` }}></div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none transition-all hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest mb-1">Foco Principal</p>
              <h3 className="text-xl font-black text-correo-blue dark:text-white mt-1 uppercase break-words leading-tight">{stats.leadProject}</h3>
            </div>
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-3xl">
              <Briefcase className="w-7 h-7 text-correo-blue dark:text-correo-yellow" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 shadow-xl transition-colors">
          <h4 className="text-sm font-black text-correo-blue dark:text-white mb-8 uppercase tracking-[0.2em] border-l-4 border-correo-yellow pl-4">Carga de Trabajo Diaria</h4>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" opacity={0.5} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 800, textTransform: 'uppercase'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 800}} />
                <Tooltip 
                  cursor={{fill: 'rgba(255, 206, 0, 0.05)'}}
                  contentStyle={{ backgroundColor: '#00205b', borderRadius: '16px', border: 'none', color: '#fff', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Bar dataKey="horas" fill="#00205b" radius={[8, 8, 0, 0]} barSize={45} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border-2 border-slate-100 dark:border-slate-800 shadow-xl transition-colors">
          <h4 className="text-sm font-black text-correo-blue dark:text-white mb-8 uppercase tracking-[0.2em] border-l-4 border-correo-yellow pl-4">Inversión por Categoría</h4>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={75}
                  outerRadius={110}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={BRAND_CHART_COLORS[index % BRAND_CHART_COLORS.length]} strokeWidth={4} stroke="#fff" />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#00205b', borderRadius: '16px', border: 'none', color: '#fff', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: '900', textTransform: 'uppercase', paddingTop: '20px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
