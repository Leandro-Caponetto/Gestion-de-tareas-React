
import { createClient } from '@supabase/supabase-js';

// Reemplaza con tus credenciales de Supabase
const supabaseUrl = 'https://TU_PROYECTO.supabase.co';
const supabaseAnonKey = 'TU_ANON_KEY';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
