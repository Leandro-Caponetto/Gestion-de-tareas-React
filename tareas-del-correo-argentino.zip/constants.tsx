
import { Task, TaskCategory } from './types';

export const INITIAL_TASKS: Task[] = [
  {
    id: '1',
    fecha: new Date().toISOString().split('T')[0],
    cliente: 'Acme Corp',
    proyecto: 'Rediseño Web',
    descripcion: 'Implementación de componentes UI en React',
    categoria: TaskCategory.Desarrollo,
    hora_inicio: '09:00',
    hora_fin: '12:30',
    total_horas: 3.5,
    etiquetas: ['frontend', 'react'],
    estado: 'Facturable'
  },
  {
    id: '2',
    fecha: new Date().toISOString().split('T')[0],
    cliente: 'Stark Ind.',
    proyecto: 'IA Jarvis',
    descripcion: 'Reunión de planificación de sprint',
    categoria: TaskCategory.Meeting,
    hora_inicio: '14:00',
    hora_fin: '15:30',
    total_horas: 1.5,
    etiquetas: ['agile', 'sprint'],
    estado: 'Facturable'
  },
  {
    id: '3',
    fecha: new Date().toISOString().split('T')[0],
    cliente: 'Wayne Ent.',
    proyecto: 'Bat-Computer',
    descripcion: 'Debugging de módulos de seguridad',
    categoria: TaskCategory.QA,
    hora_inicio: '16:00',
    hora_fin: '18:00',
    total_horas: 2.0,
    etiquetas: ['security', 'bug-hunting'],
    estado: 'No facturable'
  }
];

export const CATEGORIES = Object.values(TaskCategory);
export const CLIENTS = ['Acme Corp', 'Stark Ind.', 'Wayne Ent.', 'Cyberdyne', 'Oscorp'];
export const PROJECTS: Record<string, string[]> = {
  'Acme Corp': ['Rediseño Web', 'SEO Audit', 'App Mobile'],
  'Stark Ind.': ['IA Jarvis', 'Mark 85 Optimization', 'Arc Reactor Monitoring'],
  'Wayne Ent.': ['Bat-Computer', 'Satellite Defense', 'Gotham Infrastructure'],
  'Cyberdyne': ['Skynet Core', 'T-800 Maintenance'],
  'Oscorp': ['Serum Research', 'Glider Propulsion']
};
